-- Linea de comentarios!!
/*
	Bloque
    de
    Comentarios
*/
#Comentarios NO ANSI

show databases;					-- muestra las BDs del server

-- ; es el terminador de sentencias
-- ctrol - enter		para ejecutar



