
-- -------------    -------------------     -------------     
-- - libros    -    - prestamos       -     - socios    -    
-- -------------    -------------------     -------------     
-- - codigo PK -    - documento   PK  -     - documento -
-- - titulo    -    - codigolibro PK  -     - nombre    -
-- - autor     -    - fechaprestamo   -     - domicilio -
-- -------------    - fechadevolucion -     -------------
--                  -------------------                

drop database if exists libros;
create database libros;
use libros;

drop table if exists libros;
create table libros(
  codigo int unsigned auto_increment,
  titulo varchar(40) not null,
  autor varchar(20) default 'Desconocido',
  primary key (codigo)
);

drop table if exists socios;
create table socios(
  documento char(8) not null,
  nombre varchar(30),
  domicilio varchar(30),
  primary key (documento)
);

drop table if exists prestamos;
create table prestamos(
  documento char(8) not null,
  codigolibro int unsigned,
  fechaprestamo date not null,
  fechadevolucion date,
  primary key (codigolibro,fechaprestamo)
);
alter table prestamos
    add constraint FK_prestamos_libros
    foreign key(codigolibro) 
    references libros(codigo);

ALTER TABLE prestamos
ADD CONSTRAINT fk_prestamos_socios
FOREIGN KEY(documento) REFERENCES socios(documento);

insert into socios values('22333444','Juan Perez','Colon 345');
insert into socios values('23333444','Luis Lopez','Caseros 940');
insert into socios values('25333444','Ana Herrero','Sucre 120');

insert into libros values(1,'Java: Programar','Paul Deitel');
insert into libros values(2,'Head First Java (Edición en español)','Kathy Sierra');
insert into libros values(25,'Effective Java (Edición en español)','Joshua Bloch');
insert into libros values(42,'Aprende SQL en un fin de semana','Laura R. M.');

insert into prestamos values('22333444',1,'2025-09-20','2025-10-24');
insert into prestamos values('22333444',1,'2025-10-24',null);
insert into prestamos values('25333444',25,'2025-03-10','2006-08-13');
insert into prestamos values('25333444',42,'2025-03-10',null);
insert into prestamos values('25333444',25,'2006-08-15',null);
insert into prestamos values('22333444',42,'2006-08-02','2006-08-05');
insert into prestamos values('25333444',2,'2006-08-02','2006-08-05');

-- DBA vinculado a la infraestructora y los servidores ADMINISTRADOR DE BASES DE DATOS: CONTROLA LA INTEGRIDAD REFERENCIAL Y PONE LAS RESTRICCIONES // distinro de ANALISTA de BD

-- Usando la base de datos Libros responder la siguientes consultas.

-- 1- Que libros (codigo,titulo,autor) se le prestaron a cada socio (nombre y documento).

SELECT distinct s.nombre, p.documento, l.codigo, l.titulo, l.autor
FROM prestamos p
JOIN libros l ON l.codigo = p.codigolibro
JOIN socios s ON p.documento = s.documento
order BY s.nombre;


-- 2- Lista de socios (documento,nombre,domicilio) que se le presto libros de 'java' (like '%java%')
SELECT DISTINCT s.documento, s.nombre, s.domicilio, l.titulo
FROM socios s
JOIN prestamos p ON s.documento = p.documento
JOIN libros l ON p.codigolibro = l.codigo
WHERE l.titulo LIKE '%java%';


-- 3- Lista de libros (codigo,titulo,autor) que no fueron devueltos (fechadevolucion is null)
SELECT l.codigo, l.titulo, l.autor
FROM libros l
JOIN prestamos p ON l.codigo = p.codigolibro
WHERE p.fechadevolucion IS NULL;

-- 4- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver.
SELECT DISTINCT s.documento, s.nombre, s.domicilio
FROM socios s
JOIN prestamos p ON s.documento = p.documento
WHERE p.fechadevolucion IS NULL;


-- 5- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver y cuales son los libros.
SELECT s.documento, s.nombre, s.domicilio, l.codigo, l.titulo, l.autor
FROM socios s
JOIN prestamos p ON s.documento = p.documento
JOIN libros l ON p.codigolibro = l.codigo
WHERE p.fechadevolucion IS NULL;

-- 6- Cantidad de libros sin devolver.
SELECT COUNT(*) AS cantidad_libros_sin_devolver
FROM prestamos
WHERE fechadevolucion IS NULL;

-- 7- Lista de libros que fueron prestados el día de hoy.
SELECT l.codigo, l.titulo, l.autor
FROM libros l
JOIN prestamos p ON l.codigo = p.codigolibro
WHERE p.fechaprestamo = CURDATE();

-- 8- Cantidad de libros que se prestaron en este mes.
SELECT COUNT(*) AS cantidad_libros_prestados_mes
FROM prestamos
WHERE MONTH(fechaprestamo) = MONTH(CURDATE())
AND YEAR(fechaprestamo) = YEAR(CURDATE());

-- 9- Cantidad de libros que no fueron prestados en este mes.
SELECT COUNT(*) AS cantidad_libros_no_prestados
FROM libros l
WHERE l.codigo NOT IN (
    SELECT p.codigolibro
    FROM prestamos p
    WHERE MONTH(p.fechaprestamo) = MONTH(CURDATE())
    AND YEAR(p.fechaprestamo) = YEAR(CURDATE())
);

-- 10-Cantidad de socion que se le prestaron libros en este mes.
SELECT COUNT(DISTINCT documento) AS cantidad_socios_mes
FROM prestamos
WHERE MONTH(fechaprestamo) = MONTH(CURDATE())
AND YEAR(fechaprestamo) = YEAR(CURDATE());
